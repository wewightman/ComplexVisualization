import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.*; 
import java.util.ArrayList; 
import java.util.Scanner; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Fourier extends PApplet {

// Variables needed to manipulate the graphing space
Graph graph;
boolean zoom;
float delta;
float axisX;
float axisY;
float bufferX;
float bufferY;

// Variables needed to represent a signal
Complex[] data;
Euler[] sins;
Euler[] simple;
float[][] circles;
float[][] simpleCircles;
int timeSpan;
int time;

public void setup() {
  // defines the window and graph set
  
  axisX = 6;
  axisY = 4;
  graph = new Graph(width, axisX, -axisX, 0.5f, height, axisY, -axisY, 0.5f);
  
  // reads the data
  int numSins = 243;
  data = readTempFile(dataPath("") + "\\house.txt");
  timeSpan = data.length;
  time = 0;
  
  // completes a Fourier transform
  sins = fourier(data, numSins);
  sortSins(sins);
  
  // generates a rough approximation using 10% of sinusoids present
  simple = new Euler[sins.length/10];
  for (int i = 0; i < simple.length; ++i) {
    simple[i] = sins[i];
  }
  
  // allocates the points of the aproximations to be graphed
  circles = new float[data.length][2];
  simpleCircles = new float[data.length][2];
  
  for (int i = 0; i < data.length; ++i) {
    circles[i] = calcEnd(sins, i);
    simpleCircles[i] = calcEnd(simple, i);
  }
}

public void draw() {
  if (time >= timeSpan) {
    time = 0;
    delta *= -1;
  }
  background(50, 200, 255);
  graph.drawAxis(true);
  
  // Draws the original file
  for (int i = 1; i < data.length; ++i) {
    float x1 = graph.pixelx(data[i-1].real);
    float y1 = graph.pixely(data[i-1].imag);
    float x2 = graph.pixelx(data[i].real);
    float y2 = graph.pixely(data[i].imag);
    line(x1, y1, x2, y2);
  }
  
  drawSins(sins, time, graph);
  drawSins(simple, time, graph);
  
  for (int i = 0; i < time + 1; ++i) {
    fill(0);
    circle(graph.pixelx(circles[i][0]), graph.pixely(circles[i][1]), height/100);
    fill(255);
    circle(graph.pixelx(simpleCircles[i][0]), graph.pixely(simpleCircles[i][1]), height/100);
    //fill(255);
  }
  
  time += 1;
}

/**
 * This method reads in a text based data file
 */
public Complex[] readTempFile(String filename) {
  Complex[] data = null;
  try {
      ArrayList<Complex> dataList = new ArrayList<Complex>();
      File file = new File(filename);
      Scanner reader = new Scanner(file);
      //System.out.println("Created Scanner");
      
      float real;
      float imag;
      Scanner numReader;
      
      while (reader.hasNextLine()) {
        //System.out.println("Entered while loop...");
        String tempStr = reader.nextLine();
        //System.out.println(tempStr);
        String[] temp = tempStr.split("[+]",2);
        numReader = new Scanner(temp[0]);
        real = (float) numReader.nextDouble();
        //System.out.println("  Real: " + real);
        numReader.close();
        numReader = new Scanner(temp[1].substring(0, temp[1].length()-1));
        imag = (float) numReader.nextDouble();
        //System.out.println("  Imag: " + imag);
        dataList.add(new Complex(real, imag));
      }
      
      data = new Complex[dataList.size()];
      data = dataList.toArray(data);
      
      reader.close();
    } catch (FileNotFoundException e) {
      System.out.println("ERROR: File was not found");
    } catch (IOException e) {
      System.out.println("ERROR: An error occured while reading the file");
    } catch (Error e) {
      System.out.println("ERROR: Some unexpected error occured");
    }
    
    return data;
}

/**
 * This method completes a discrete Fourier transform for a discrete data set
 * @param data a dicrete signal comprized of complex numbers
 * @param N the number of sinusoids used in the signal
 * @return a set of euler sinusoids with a length of N
 */
public Euler[] fourier(Complex[] data, int N) {
  Complex[] coefs = new Complex[N];
  
  // Gets the complex coefficients of each frequency
  for (int i = 0; i < N; ++i) {
    Euler multiplier = new Euler(1, 0, -2*PI*(float)i/((float)N));
    coefs[i] = multiplier.getTime(0).product(data[0]);
    
    for (int j = 1; j < data.length; ++j) {
      coefs[i] = coefs[i].sum(multiplier.getTime(j).product(data[j]));
    }
    coefs[i] = new Complex(coefs[i].real/((float)N), coefs[i].imag/((float)N));
  }
  
  // Generates a list of complex Euler sinusoids
  Euler[] sins = new Euler[N];
  for (int i = 0; i < N; ++i) {
    sins[i] = new Euler(coefs[i].getMag(), coefs[i].getAng(), 2*PI*(float)i/((float)N));
  }
  
  return sins;
}

/**
 * This method sorts an array of euler sinusoids from largest magitude to smallest
 */
public void sortSins(Euler[] input) {
  // Sorts the sinusoids by magnitude
  for (int i = 0; i < input.length; ++i) {
    for (int j = 1; j < input.length; ++j) {
      if (input[j].mag > input[j-1].mag) {
        Euler temp = input[j];
        input[j] = input[j-1];
        input[j-1] = temp;
      }
    }
  }
}

/*
 * This method draws a set of sinusoids with the previous sinusoids head aligning with the other sinusoids tail
 */
public float[] drawSins(Euler[] sins, float time, Graph graph) {
  float[] prevEnd = {0, 0};
  float[] newEnd;
  
  // Draws each arrow end to end
  //System.out.println("Entering for loop - Time: " + time + " Time Span: " + timeSpan);
  for (int i = 0; i < sins.length; ++i) {
    Complex sin = sins[i].getTime(time);
    newEnd = new float[]{prevEnd[0] + sin.real, prevEnd[1] + sin.imag};
    new Arrow(prevEnd, newEnd).draw(graph);
    prevEnd = newEnd;
  }
  
  return prevEnd;
}

/**
 * Calculates the sum of euler sinusoids at a given time
 */
public float[] calcEnd(Euler[] sins, float time) {
  float real = 0;
  float imag = 0;
  // Draws each arrow end to end
  for (int i = 0; i < sins.length; ++i) {
    Complex sin = sins[i].getTime(time);
    real += sin.real;
    imag += sin.imag;
  }
 
  return new float[]{real,imag};
}




public class Complex {
  public float real;
  public float imag;
  
  public Complex(float real, float imag) {
    this.real = real;
    this.imag = imag;
  }
  
  /**
   * This method calculates the angle of the vector
   * @return the angle of this complex between +/- PI
   */
  public float getAng() {
    return (float) Math.atan2(this.imag, this.real);
  }
  
  /**
   * This method gets the magnitude of the complex number
   * @return the magnitude of this complex number
   */
  public float getMag() {
    return (float)Math.sqrt(real*real + imag*imag);
  }
  
  public Complex product(Complex second) {
    float real = this.real*second.real-this.imag*second.imag;
    float imag = this.imag*second.real + this.real*second.imag;
    
    return new Complex(real, imag);
  }
  
  public Complex sum(Complex second) {
    float real = this.real + second.real;
    float imag = this.imag + second.imag;
    
    return new Complex(real, imag);
  }
  
  public String toString() {
    return "" + real + " + " + imag + "*i";
  }
} 

public class Euler {
  public float mag;
  public float phi;
  public float omega;
  
  // Constructor
  public Euler(float mag, float phi, float omega) {
    this.mag = mag;
    this.phi = phi;
    this.omega = omega;
  }
  
  // Returns a complex at a given time
  public Complex getTime(float time) {
    return new Complex(mag*cos(omega*time+phi),mag*sin(omega*time+phi));
  }
  
  public String toString() {
    return "" + mag + "\t" + phi + "\t" + omega;
  }
}
class Graph {
  // x data
  private float xlim;
  private float xmax;
  private float xmin;
  private float xtick;
  private float xzero;
  private float pxpnx; // Pixels (x) per number x
  
  // y data
  private float ylim;
  private float ymax;
  private float ymin;
  private float ytick;
  private float yzero;
  private float pypny; // Pixels (y) per number y
  
  /**
   * Contructor that builds the pure numerical to pixel coordinates
   */
  public Graph(float xlim, float xmax, float xmin, float xtick, float ylim, float ymax, float ymin, float ytick) {
    this.xlim = xlim; this.xmax = xmax; this.xmin = xmin; this.xtick = xtick;
    this.ylim = ylim; this.ymax = ymax; this.ymin = ymin; this.ytick = ytick;
    
    this.pxpnx = xlim/(xmax-xmin); // Calculates pixels per unit one on x axis
    this.pypny = ylim/(ymax-ymin); // Calculates pixels per unit one on y axis
    this.xzero = -xmin*pxpnx; // Calculates the px zero
    this.yzero = ymax*pypny; // Calculates the py zero
  }
  
  /**
   * This method converts a numerical value in x to a pixel
   * @param orig this is the numerical coordinte you wish to plot
   * @return the pixel that number coordinates to as a float
   */
  public float pixelx(float num) {
    return num*pxpnx + xzero;
  }
  
  /**
   * This method converts a pixel value in the x axis to a numerical value
   * @param pix the x pixel value
   * @return the numerical value according to this graphs space
   */
  public float numx(float pix) {
    return xmin + pix/pxpnx;
  }
  
  /**
   * This method converts a numerical value of y to a pixel
   * @param orig the numerical coordinate to be ploted
   * @return the pixel coordinated to that number
   */
   public float pixely(float num) {
     return (ymax-num)*pypny;
   }
   
   /**
    * This method converts a pixel value in y to a numerical value
    * @param pix the y pixel value
    * @return the numerical y value associated with that pixel
    */
    public float numy(float pix) {
      return ymax - pix/pypny;
    }
   
   /**
    * This function draws the axis of the graph.
    * These are graphed with a numerical spacing defined by the tick-marks.
    * If the tick marks are equivalent to zero, no markings are displayed
    * FIXME - if the axis isn't within the window, draws the tickmarks on edge
    */
    public void drawAxis(boolean ticks) {
      line(xzero, 0, xzero, ylim);
      line(0, yzero, xlim, yzero);
      
      // Draws ticks if needed.
      if (ticks) {
        drawTicks();
      }
    }
    
    /**
     * Helper method that draws ticks at the specified intervals
     */
    private void drawTicks() {
      if (xtick > 0) {
        float curx = xzero;
        while (curx < xlim) {
          curx += xtick*pxpnx;
          line(curx, yzero + 0.02f*ylim, curx, yzero - 0.02f*ylim);
        }
        curx = xzero;
        while (curx > 0) {
          curx -= xtick*pxpnx;
          line(curx, yzero + 0.02f*ylim, curx, yzero - 0.02f*ylim);
        }
      }
      if (ytick > 0) {
        float cury = yzero;
        while (cury > 0) {
          cury -= ytick*pypny;
          line(xzero - 0.02f*xlim, cury, xzero + 0.02f*xlim, cury);
        }
        cury = yzero;
        while (cury < ylim) {
          cury += ytick*pypny;
          line(xzero - 0.02f*xlim, cury, xzero + 0.02f*xlim, cury);
        }
      }
    }
}
class Arrow {
  private float[] coords = new float[2];
  private float[] unit = new float[2];
  private float[] head = new float[6];
  private float mag;
  private int rgb;
  
  public Arrow(float[] coords, float[] unit, float mag, int rgb) {
    if (coords.length != unit.length) {
      throw new IllegalArgumentException("Coordinates and direction not defined with same dinensions");
    }
    if (coords.length != 2) {
      throw new IllegalArgumentException("Vectors must be defined in only two dimensions");
    }
    
    this.coords = coords;
    this.unit = unit;
    this.mag = mag;
    this.head = updateHead();
    this.rgb = rgb;
  }
  
  public Arrow(float[] root, float[] tip) {
    this.coords = root;
    this.rgb = 0;
    this.setEnd(tip[0],tip[1]);
  }
  
  // Calculates the corners of the head of the triangle
  private float[] updateHead() {
    head[0] = coords[0] + unit[0]*mag;
    head[1] = coords[1] + unit[1]*mag;
    
    float[] base = {(coords[0]+0.8f*unit[0]*mag), (coords[1]+0.8f*unit[1]*mag)};
    
    head[2] = base[0] - 0.1f*mag*unit[1];
    head[3] = base[1] + 0.1f*mag*unit[0];
    head[4] = base[0] + 0.1f*mag*unit[1];
    head[5] = base[1] - 0.1f*mag*unit[0];
    
    return head;
  }
  
   public void draw(){
     line(coords[0],coords[1], coords[0] + mag*unit[0], coords[1] + mag*unit[1]);
     updateHead();
     triangle(head[0], head[1], head[2], head[3], head[4], head[5]);
     fill(rgb);
   }
   
   public void drawUnit(Graph graph) {
     float[] transBase = {graph.pixelx(coords[0]), graph.pixely(coords[1])};
     float[] transHead = {graph.pixelx(coords[0] + unit[0]), graph.pixely(coords[1] + unit[1])};
     new Arrow(transBase, transHead).draw();
   }
   
   public void draw(Graph graph) {
     float[] transBase = {graph.pixelx(coords[0]), graph.pixely(coords[1])};
     float[] transHead = {graph.pixelx(coords[0] + mag*unit[0]), graph.pixely(coords[1] + mag*unit[1])};
     new Arrow(transBase, transHead).draw();
   }
   
   public void setUnit(float[] unit){
     this.unit = unit;
   }
   
   public void setMag(float mag) {
     this.mag = mag;
     head[0] = unit[0]*mag;
     head[1] = unit[1]*mag;
   }
   
   public void setEnd (float xco, float yco) {
     float dx = xco - coords[0];
     float dy = yco - coords[1];
     this.mag = (float)Math.sqrt(dx*dx + dy*dy);
     
     this.unit = new float[]{dx/this.mag, dy/this.mag};
   }
}
  public void settings() {  size(800, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Fourier" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
